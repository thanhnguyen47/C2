# Infected

> malware 

> communicate with server C2 through http 

