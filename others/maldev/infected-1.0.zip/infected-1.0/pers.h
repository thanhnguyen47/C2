#pragma once

#include <Windows.h>
#include <stdio.h>

BOOL SetPersReg(const WCHAR* appPath);
